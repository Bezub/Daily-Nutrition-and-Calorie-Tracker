#ifndef RECOMMENDATIONS_H
#define RECOMMENDATIONS_H

#include "models.h"

void runMealRecommendations(const UserProfile& p);
void runEndDaySummary(const UserProfile& p);

#endif

