#ifndef FOOD_H
#define FOOD_H

#include "models.h"
#include <vector>

void runAddFood(const UserProfile& p);
void runViewConsumption(const UserProfile& p);
void runAddCustomFood(const UserProfile& p);

#endif
